<?php
include_once 'Db.php';
 $id = $_POST['product_id'];
 $quantity = $_POST['qty'];
 $action = $_POST['action'];
 echo $id;
 exit;
?>