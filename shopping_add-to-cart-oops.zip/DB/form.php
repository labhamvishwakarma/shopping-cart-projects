<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link
         href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css"
         rel="stylesheet"
         integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU"
         crossorigin="anonymous">
      <!-- <script src="form.js"></script> -->
      <link rel="stylesheet" href="style.css">
      <title>Registration Form</title>
   </head>
   <body class="bg-color">
      <section class="container mt-5">
         <div class="row justify-content-md-center">
            <form class="col-md-6 col-sm-12 bg-white p-5 rounded shadow" action="Db.php" method="POST">
               <div class="col-12 text-center">
                  <h3 class="text-primary"><strong>Registration</strong></h3>
                  <hr>
               </div>
               <div class="mb-3">
                  <label for="firstname">Firstname</label>
                  <input id="firstname" type="text" name="firstname"
                     class="form-control" value=""
                     >
               </div>
               <p id="demo"></p>
               <div class="mb-3">
                  <label for="lastname">Lastname</label>
                  <input id="lastname" type="text" name="lastname"
                     value=""
                     class="form-control" >
               </div>
               <div class="mb-3">
                  <label for="Phone-No">Phone No</label>
                  <input id="Phone" type="text" name="Phoneno"
                     class="form-control" maxlength="12">
               </div>
               <div class="mb-3">
                  <label for="email" class="form-label">Email address</label>
                  <input id="email" type="email" name="email"
                     class="form-control">
               </div>
               <div class="mb-3">
                  <label for="hobbies"> Hobbies</label><br>
                  <input  type="checkbox" name="hobbies"
                     value="videogame">
                  <label for="hobbies"> videogame</label><br>
                  <input  type="checkbox" name="hobbies"
                     value="Codding">
                  <label for="hobbies">Codding</label><br>
                  <input type="checkbox" name="hobbies"
                     value="hockey">
                  <label for="hobbies">hockey</label><br>
                  <input  type="checkbox" name="hobbies"
                     value="dancing">
                  <label for="hobbies">dancing</label><br>
                  <input  type="checkbox" name="hobbies"
                     value="Codding">
                  <label for="hobbies">Codding</label><br>
                  <input type="checkbox" name="hobbies"
                     value="singing">
                  <label for="hobbies">singing</label><br>
                  <input  type="checkbox" name="hobbies"
                     value="travelling">
                  <label for="hobbies">travelling</label><br>
                  <input type="checkbox" name="hobbies"
                     value=" Cricket">
                  <label for="hobbies"> Cricket</label><br><br>
               </div>
               <div class="mb-3">
                  <label for="gender">Gender</label>
                  <input type="radio" name="gender"
                     value="male"> Male
                  <input
                     type="radio" name="gender"
                     value="female"> Female
               </div>
               <div class="mb-3">
                  <label for="password" class="form-label">Password</label>
                  <input id="pswd" type="password" name="pswd" class="form-control"
                     >
               </div>
               <div class="mb-3">
                  <label for="confirm_password" class="form-label">Confirm
                  Password</label>
                  <input id="cpswd" type="password" name="c_password" class="form-control"
                     >
               </div>
               <div class="mb-3">
                  <label for="files" class="form-label">files upload
                  </label>
                  <input type="file" name="fileToUpload" id="fileToUpload" class="form-control">
               </div>
               <input type="hidden" name="register" value="register" >
               <div>
                  <input type="checkbox" class="form-check-input" id="terms"  name="terms" >
                  <label class="form-check-label" for="terms">I agree
                  terms and conditions.</label>
               </div>
               <p class="error" id="error"></p>
               <div class="text-center mt-3">
                  <button type="submit" onclick="validate()" class="btn
                     btn-danger btn-rounded
                     w-75">Register Now</button>
               </div>
               <div class="text-center mt-3">
                  <button type="submit"><a class="text-danger text-decoration-none" href="login.php"> Login </a></button>
               </div>
            </form>
         </div>
      </section>
   </body>
</html>