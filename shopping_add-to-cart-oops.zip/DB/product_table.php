<?php
session_start();
include "Db.php";
$id = $_GET['product_id'];

$obj = new Db();
  //  $_SESSION['data'] = array();
$data = $obj->add_to_cart($id);
// echo"<pre>";print_r($data);
if (empty($_SESSION['data'])){
  if(!empty($data)){
    array_push($_SESSION['data'],$data);
  }}
  
// echo"<pre>";print_r($_SESSION);
$cnt = 0;
foreach($_SESSION['data'] as $key=>$value){
     if($id == $value['id']){
    $cnt++;
     }
}
if($cnt==0){
  array_push($_SESSION['data'],$data);
} 

// echo"<pre>";print_r($_SESSION);
// exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet"/>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"rel="stylesheet"/>
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/5.0.0/mdb.min.css"rel="stylesheet"/>
    <!-- MDB -->
    <script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/5.0.0/mdb.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>Document</title>
</head>
<body>
<table class="table align-middle mb-0 bg-white">

                

  <thead class="bg-light">
  <?php 
  if(isset($_SESSION['data'])){
    // exit(1);
  foreach($_SESSION['data'] as $key=>$product){
              if(!empty($product))
                      {
                        // echo"<pre>";print_r($_SESSION);

                      ?>
    <tr>
      <th class="text-uppercase">PRODUCT Name</th>
      <th class="text-uppercase">PRODUCT DETAILS</th>
      <th class="text-uppercase">QUANTITY</th>
      <th class="text-uppercase">PRICE</th>
      <th class="text-uppercase">Actions</th>
    </tr>
  </thead>
  <tbody>
    <tr id =<?php echo $product['id']; ?>>
      <td>
        <div class="d-flex align-items-center">
          <img
              src="images/<?php echo $product['image']; ?>"
              class="border border-warning"
              alt=""
              style="width: 90px; height: 90px; border 2px solid red"
              />
          <div class="ms-3">
            <p class="fw-bold mb-1 text-warning text-uppercase"><?php echo $product['product_name']; ?></p>
            <p class="text-muted mb-0 text-danger text-uppercase"><?php echo $product['squ']; ?></p>
          </div>
        </div>
      </td>
      <td>
      <p class="text-uppercase"><?php echo $product['product_deatil']; ?></p>
      </td>
      <td><input type="number" id="qty" value="<?php echo $product['quantity']; ?>"min="1"></td>
      <td>
          <?php echo $product['price']; ?>
      </td>
    
      <td>
      <button data-mdb-ripple-color="danger"  class="btn btn-success" type="button" onclick="update_Qty(<?php echo $product['id']?> , 'update')";>
          UPDATE
        </button>
        <button data-mdb-ripple-color="light"  class="btn btn-dark" type="button" onclick="update_Qty(<?php echo $product['id']?> , 'delete')"; >
                
          DELETE
        </button>
      </td>
    </tr>
     <?php }
     }}
      ?>
  </tbody>
 
</table> 


<script>
function update_Qty(id,action) {
  var quantity = document.getElementById("qty").value;
  alert('<?= $_SERVER['HTTP_HOST'] ?>');
  var path = '<?php $_SERVER['HTTP_HOST'] ?>/Labham/DB/Db.php';
	$.ajax({
		url: path,
		type: "POST",
		data: 'qty='+quantity+'&product_id='+id+'&action='+action,
		success: function(data){
      console.log(data);
     $('#'+id).hide();
    }
	  
    
	});
}

</script>
</body>
</html>