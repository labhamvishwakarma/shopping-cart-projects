function validate() {
    var firstname = document.getElementById('firstname').value;
    var lastname = document.getElementById('lastname').value;
    var Phone = document.getElementById('Phone').value;
    var email = document.getElementById('email').value;
    var checkBoxes = document.querySelectorAll('input[type="checkbox"]');
    let error = true;
    var hobbies = [];
 
    checkBoxes.forEach(item => { // loop all the checkbox item
       if (item.checked) { //if the check box is checked
          error = false;
          hobbies.push(item.value);
 
       }
    });
    var pswd = document.getElementById('pswd').value;
    var cpswd = document.getElementById('cpswd').value;
    var terms = document.querySelector('input[name="terms"]');
 
 
    if (firstname == "" || lastname == "" || Phone == "" || email == "" || checkBoxes == "" || gender == "" || pswd == "" || cpswd == "" || terms.checked == false) {
       document.getElementById('error').innerHTML = "<b>*All field must be filled</b>";
       document.getElementById('error').style.display = 'inline-block';
    } else {
       document.getElementById('error').style.display = 'none';
 
    }
    var regName = /^[a-z][a-z\s]*$/;
    if (!firstname.match(regName)) {
       alert('Please enter firstname');
       return false;
    }
    var regName = /^[a-z][a-z\s]*$/;
    if (!lastname.match(regName)) {
       alert('Please enter lastname');
       return false;
    }
 
 
    var regName = /^\+(?:[0-9] ?){6,14}[0-9]$/;
    if (isNaN(Phone)) {
       alert('Please enter numeric digits only');
       return false;
    }
    if (Phone == "") {
       alert('Please enter your phone number');
       return false;
    }
    if (Phone.length < 10) {
       alert("Please enter 10 digit mobile no.");
    }
    var regName = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (!email.match(regName)) {
       alert('Please enter valid Email');
       return false;
    }
 
    if (hobbies.length < 1) {
       alert("please select hobbies");
       return false;
    }
    var gender = document.querySelectorAll('input[type="radio"]');
    var gender_value = '';
 
 
    gender.forEach(item => { // loop all the checkbox item
       if (item.checked) {
          gender_value = item.value; //if the check box is checke
 
       }
 
    });
    if (gender_value == '') {
 
       alert("please select gender");
       return false;
 
    }
    var pswdj = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{3,20}$/;
    if (!pswd.match(pswdj)) {
       alert('your password  not match A-z/@/$%/&/1-9.etc./')
       return true;
    }
 
    var cpswdj = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{3,20}$/;
    if (!cpswd.match(cpswdj)) {
       alert('please enter the correct password')
       return true;
    }
 
    if (pswd !== cpswd) {
       alert("password not matched")
 
    }
    if (!terms.checked) {
       alert("please accept term and conditions");
 
    }
 
    console.log(firstname, lastname, Phone, email, hobbies, gender_value, pswd, cpswd);
 }
 
 
 function validate() {
    var firstname = document.getElementById('firstname').value;
    var lastname = document.getElementById('lastname').value;
    var Phone = document.getElementById('Phone').value;
    var email = document.getElementById('email').value;
    var checkBoxes = document.querySelectorAll('input[type="checkbox"]');
    let error = true;
    var hobbies = [];
 
    checkBoxes.forEach(item => { // loop all the checkbox item
       if (item.checked) { //if the check box is checked
          error = false;
          hobbies.push(item.value);
 
       }
    });
    var pswd = document.getElementById('pswd').value;
    var cpswd = document.getElementById('cpswd').value;
    var terms = document.querySelector('input[name="terms"]');
 
 
    if (firstname == "" || lastname == "" || Phone == "" || email == "" || checkBoxes == "" || gender == "" || pswd == "" || cpswd == "" || terms.checked == false) {
       document.getElementById('error').innerHTML = "<b>*All field must be filled</b>";
       document.getElementById('error').style.display = 'inline-block';
    } else {
       document.getElementById('error').style.display = 'none';
 
    }
    var regName = /^[a-z][a-z\s]*$/;
    if (!firstname.match(regName)) {
       alert('Please enter firstname');
       return false;
    }
    var regName = /^[a-z][a-z\s]*$/;
    if (!lastname.match(regName)) {
       alert('Please enter lastname');
       return false;
    }
 
 
    var regName = /^\+(?:[0-9] ?){6,14}[0-9]$/;
    if (isNaN(Phone)) {
       alert('Please enter numeric digits only');
       return false;
    }
    if (Phone == "") {
       alert('Please enter your phone number');
       return false;
    }
    if (Phone.length < 10) {
       alert("Please enter 10 digit mobile no.");
    }
    var regName = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (!email.match(regName)) {
       alert('Please enter valid Email');
       return false;
    }
 
    if (hobbies.length < 1) {
       alert("please select hobbies");
       return false;
    }
    var gender = document.querySelectorAll('input[type="radio"]');
    var gender_value = '';
 
 
    gender.forEach(item => { // loop all the checkbox item
       if (item.checked) {
          gender_value = item.value; //if the check box is checke
 
       }
 
    });
    if (gender_value == '') {
 
       alert("please select gender");
       return false;
 
    }
    var pswdj = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{3,20}$/;
    if (!pswd.match(pswdj)) {
       alert('your password  not match A-z/@/$%/&/1-9.etc./')
       return true;
    }
 
    var cpswdj = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{3,20}$/;
    if (!cpswd.match(cpswdj)) {
       alert('please enter the correct password')
       return true;
    }
 
    if (pswd !== cpswd) {
       alert("password not matched")
 
    }
    if (!terms.checked) {
       alert("please accept term and conditions");
 
    }
 
    console.log(firstname, lastname, Phone, email, hobbies, gender_value, pswd, cpswd);
 }
 
 
 function validate() {
    var firstname = document.getElementById('firstname').value;
    var lastname = document.getElementById('lastname').value;
    var Phone = document.getElementById('Phone').value;
    var email = document.getElementById('email').value;
    var checkBoxes = document.querySelectorAll('input[type="checkbox"]');
    let error = true;
    var hobbies = [];
 
    checkBoxes.forEach(item => { // loop all the checkbox item
       if (item.checked) { //if the check box is checked
          error = false;
          hobbies.push(item.value);
 
       }
    });
    var pswd = document.getElementById('pswd').value;
    var cpswd = document.getElementById('cpswd').value;
    var terms = document.querySelector('input[name="terms"]');
 
 
    if (firstname == "" || lastname == "" || Phone == "" || email == "" || checkBoxes == "" || gender == "" || pswd == "" || cpswd == "" || terms.checked == false) {
       document.getElementById('error').innerHTML = "<b>*All field must be filled</b>";
       document.getElementById('error').style.display = 'inline-block';
    } else {
       document.getElementById('error').style.display = 'none';
 
    }
    var regName = /^[a-z][a-z\s]*$/;
    if (!firstname.match(regName)) {
       alert('Please enter firstname');
       return false;
    }
    var regName = /^[a-z][a-z\s]*$/;
    if (!lastname.match(regName)) {
       alert('Please enter lastname');
       return false;
    }
 
 
    var regName = /^\+(?:[0-9] ?){6,14}[0-9]$/;
    if (isNaN(Phone)) {
       alert('Please enter numeric digits only');
       return false;
    }
    if (Phone == "") {
       alert('Please enter your phone number');
       return false;
    }
    if (Phone.length < 10) {
       alert("Please enter 10 digit mobile no.");
    }
    var regName = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (!email.match(regName)) {
       alert('Please enter valid Email');
       return false;
    }
 
    if (hobbies.length < 1) {
       alert("please select hobbies");
       return false;
    }
    var gender = document.querySelectorAll('input[type="radio"]');
    var gender_value = '';
 
 
    gender.forEach(item => { // loop all the checkbox item
       if (item.checked) {
          gender_value = item.value; //if the check box is checke
 
       }
 
    });
    if (gender_value == '') {
 
       alert("please select gender");
       return false;
 
    }
    var pswdj = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{3,20}$/;
    if (!pswd.match(pswdj)) {
       alert('your password  not match A-z/@/$%/&/1-9.etc./')
       return true;
    }
 
    var cpswdj = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{3,20}$/;
    if (!cpswd.match(cpswdj)) {
       alert('please enter the correct password')
       return true;
    }
 
    if (pswd !== cpswd) {
       alert("password not matched")
 
    }
    if (!terms.checked) {
       alert("please accept term and conditions");
 
    }
 
    console.log(firstname, lastname, Phone, email, hobbies, gender_value, pswd, cpswd);
 }

//  -----------------dashboard-----------
let menuIcon = document.querySelector('.menuIcon');
        let nav = document.querySelector('.overlay-menu');

        menuIcon.addEventListener('click', () => {
            if (nav.style.transform != 'translateX(0%)') {
                nav.style.transform = 'translateX(0%)';
                nav.style.transition = 'transform 0.2s ease-out';
            } else { 
                nav.style.transform = 'translateX(-100%)';
                nav.style.transition = 'transform 0.2s ease-out';
            }
        });


        // Toggle Menu Icon ========================================
        let toggleIcon = document.querySelector('.menuIcon');

        toggleIcon.addEventListener('click', () => {
            if (toggleIcon.className != 'menuIcon toggle') {
                toggleIcon.className += ' toggle';
            } else {
                toggleIcon.className = 'menuIcon';
            }
        });