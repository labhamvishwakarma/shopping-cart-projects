<?php

// session_start();
// $_SESSION['Email'];

    session_destroy();
    // echo '<pre>';print_r($_SESSION);exit;
    header('location:login.php');// Or wherever you want to redirect
?>
