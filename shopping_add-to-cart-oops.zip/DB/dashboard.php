<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      
      <!-- JavaScript Bundle with Popper -->
      <!-- CSS only -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="style.css">
      <title>Dashboard</title>
   </head>
   <style>body {
      margin: 0;
      font-family: Roboto,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
      font-size: .8125rem;
      font-weight: 400;
      line-height: 1.5385;
      color: #333;
      text-align: left;
      background-color: #2196F3;
      }
      .mt-50{
      margin-top: 50px;
      }
      .mb-50{
      margin-bottom: 50px;
      }
      .card {
      position: relative;
      display: -ms-flexbox;
      display: flex;
      -ms-flex-direction: column;
      flex-direction: column;
      min-width: 0;
      word-wrap: break-word;
      background-color: #fff;
      background-clip: border-box;
      border: 1px solid rgba(0,0,0,.125);
      border-radius: .1875rem;
      }
      .card-img-actions {
      position: relative;
      }
      .card-body {
      -ms-flex: 1 1 auto;
      flex: 1 1 auto;
      padding: 1.25rem;
      text-align: center;
      }
      .card-img{
      width: 350px;
      }
      .star{
      color: red;
      }
      .bg-cart {
      background-color:orange;
      color:#fff;
      }
      .bg-cart:hover {
      color:#fff;
      }
      .bg-buy {
      background-color:green;
      color:#fff;
      padding-right: 29px;
      }
      .bg-buy:hover {
      color:#fff;
      }
      a{
      text-decoration: none !important;
      }
      .ratings i{font-size: 16px;color: red}.strike-text{color: red;text-decoration: line-through}.product-image{width: 100%}.dot{height: 7px;width: 7px;margin-left: 6px;margin-right: 6px;margin-top: 3px;background-color: blue;border-radius: 50%;display: inline-block}.spec-1{color: #938787;font-size: 15px}h5{font-weight: 400}.para{font-size: 16px}
   </style>
   <body>
      <div class="container-fluid">
         <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
            <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">Company name</a>
            <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
            <div class="navbar-nav">
               <div class="nav-item text-nowrap">
                  <a class="nav-link px-3" href="#">Sign out</a>
               </div>
            </div>
         </header>
         <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
               <div class="position-sticky pt-3">
                  <ul class="nav flex-column">
                     <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home" aria-hidden="true">
                              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                              <polyline points="9 22 9 12 15 12 15 22"></polyline>
                           </svg>
                           Dashboard
                        </a>
                     </li>
                     <li class="nav-item">
                        <a class="nav-link" href="#">
                           <svg img="images/pixel" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file" aria-hidden="true">
                              <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                              <polyline points="13 2 13 9 20 9"></polyline>
                           </svg>
                           Orders
                        </a>
                     </li>
                     <li class="nav-item">
                        <a class="nav-link color-red" href="dashboard.php">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart" aria-hidden="true">
                              <circle cx="9" cy="21" r="1"></circle>
                              <circle cx="20" cy="21" r="1"></circle>
                              <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                           </svg>
                           Products
                        </a>
                     </li>
                     <li class="nav-item">
                        <a class="nav-link" href="#">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users" aria-hidden="true">
                              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                              <circle cx="9" cy="7" r="4"></circle>
                              <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                              <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                           </svg>
                           Customers
                        </a>
                     </li>
                     <li class="nav-item">
                        <a class="nav-link" href="#">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bar-chart-2" aria-hidden="true">
                              <line x1="18" y1="20" x2="18" y2="10"></line>
                              <line x1="12" y1="20" x2="12" y2="4"></line>
                              <line x1="6" y1="20" x2="6" y2="14"></line>
                           </svg>
                           Reports
                        </a>
                     </li>
                     <li class="nav-item">
                        <a class="nav-link" href="#">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layers" aria-hidden="true">
                              <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                              <polyline points="2 17 12 22 22 17"></polyline>
                              <polyline points="2 12 12 17 22 12"></polyline>
                           </svg>
                           Integrations
                        </a>
                     </li>
                  </ul>
               </div>
            </nav>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
               <div class="chartjs-size-monitor">
                  <div class="chartjs-size-monitor-expand">
                     <div class=""></div>
                  </div>
                  <div class="chartjs-size-monitor-shrink">
                     <div class=""></div>
                  </div>
               </div>
               <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                  <h1 class="h2">Dashboard</h1>
                  <div class="btn-toolbar mb-2 mb-md-0">
                     <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
                     </div>
                     <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-calendar" aria-hidden="true">
                           <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                           <line x1="16" y1="2" x2="16" y2="6"></line>
                           <line x1="8" y1="2" x2="8" y2="6"></line>
                           <line x1="3" y1="10" x2="21" y2="10"></line>
                        </svg>
                        This week
                     </button>
                  </div>
               </div>
               <!-- <canvas class="my-4 w-100 chartjs-render-monitor" id="myChart" style="display: block; width: 1076px; height: 454px;" width="1076" height="454"></canvas> -->
               <div class="container d-flex justify-content-center mt-50 mb-50">
                  <div class="row">
                     <div class="col-md-4 mt-2">
                        <div class="card">
                           <div class="card-body">
                              <div class="card-img-actions">
                                 <img src="https://res.cloudinary.com/dxfq3iotg/image/upload/v1562074043/234.png" class="card-img img-fluid" width="96" height="350" alt="">
                              </div>
                           </div>
                           <div class="card-body bg-light text-center">
                              <div class="mb-2">
                                 <h6 class="font-weight-semibold mb-2">
                                    <a href="#" class="text-default mb-2" data-abc="true">Toshiba Notebook with 500GB HDD & 8GB RAM</a>
                                 </h6>
                                 <a href="#" class="text-muted" data-abc="true">Laptops & Notebooks</a>
                              </div>
                              <h3 class="mb-0 font-weight-semibold">$250.99</h3>
                              <div>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                              </div>
                              <div class="text-muted mb-3">34 reviews</div>
                              <button type="button" class="btn bg-cart"><i class="fa fa-cart-plus mr-2"></i> Add to cart</button>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-4 mt-2">
                        <div class="card">
                           <div class="card-body">
                              <div class="card-img-actions">
                                 <img src="https://res.cloudinary.com/dxfq3iotg/image/upload/v1562074043/234.png" class="card-img img-fluid" width="96" height="350" alt="">
                              </div>
                           </div>
                           <div class="card-body bg-light text-center">
                              <div class="mb-2">
                                 <h6 class="font-weight-semibold mb-2">
                                    <a href="#" class="text-default mb-2" data-abc="true">Toshiba Notebook with 500GB HDD & 8GB RAM</a>
                                 </h6>
                                 <a href="#" class="text-muted" data-abc="true">Laptops & Notebooks</a>
                              </div>
                              <h3 class="mb-0 font-weight-semibold">$250.99</h3>
                              <div>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                              </div>
                              <div class="text-muted mb-3">34 reviews</div>
                              <button type="button" class="btn bg-cart"><i class="fa fa-cart-plus mr-2"></i> Add to cart</button>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-4 mt-2">
                        <div class="card">
                           <div class="card-body">
                              <div class="card-img-actions">
                                 <img src="https://res.cloudinary.com/dxfq3iotg/image/upload/v1562074043/234.png" class="card-img img-fluid" width="96" height="350" alt="">
                              </div>
                           </div>
                           <div class="card-body bg-light text-center">
                              <div class="mb-2">
                                 <h6 class="font-weight-semibold mb-2">
                                    <a href="#" class="text-default mb-2" data-abc="true">Toshiba Notebook with 500GB HDD & 8GB RAM</a>
                                 </h6>
                                 <a href="#" class="text-muted" data-abc="true">Laptops & Notebooks</a>
                              </div>
                              <h3 class="mb-0 font-weight-semibold">$250.99</h3>
                              <div>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                              </div>
                              <div class="text-muted mb-3">34 reviews</div>
                              <button type="button" class="btn bg-cart"><i class="fa fa-cart-plus mr-2"></i> Add to cart</button>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-4 mt-2">
                        <div class="card">
                           <div class="card-body">
                              <div class="card-img-actions">
                                 <img src="https://res.cloudinary.com/dxfq3iotg/image/upload/v1562074043/234.png" class="card-img img-fluid" width="96" height="350" alt="">
                              </div>
                           </div>
                           <div class="card-body bg-light text-center">
                              <div class="mb-2">
                                 <h6 class="font-weight-semibold mb-2">
                                    <a href="#" class="text-default mb-2" data-abc="true">Toshiba Notebook with 500GB HDD & 8GB RAM</a>
                                 </h6>
                                 <a href="#" class="text-muted" data-abc="true">Laptops & Notebooks</a>
                              </div>
                              <h3 class="mb-0 font-weight-semibold">$250.99</h3>
                              <div>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                              </div>
                              <div class="text-muted mb-3">34 reviews</div>
                              <button type="button" class="btn bg-cart"><i class="fa fa-cart-plus mr-2"></i> Add to cart</button>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-4 mt-2">
                        <div class="card">
                           <div class="card-body">
                              <div class="card-img-actions">
                                 <img src="https://res.cloudinary.com/dxfq3iotg/image/upload/v1562074043/234.png" class="card-img img-fluid" width="96" height="350" alt="">
                              </div>
                           </div>
                           <div class="card-body bg-light text-center">
                              <div class="mb-2">
                                 <h6 class="font-weight-semibold mb-2">
                                    <a href="#" class="text-default mb-2" data-abc="true">Toshiba Notebook with 500GB HDD & 8GB RAM</a>
                                 </h6>
                                 <a href="#" class="text-muted" data-abc="true">Laptops & Notebooks</a>
                              </div>
                              <h3 class="mb-0 font-weight-semibold">$250.99</h3>
                              <div>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                              </div>
                              <div class="text-muted mb-3">34 reviews</div>
                              <button type="button" class="btn bg-cart"><i class="fa fa-cart-plus mr-2"></i> Add to cart</button>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-4 mt-2">
                        <div class="card">
                           <div class="card-body">
                              <div class="card-img-actions">
                                 <img src="https://res.cloudinary.com/dxfq3iotg/image/upload/v1562074043/234.png" class="card-img img-fluid" width="96" height="350" alt="">
                              </div>
                           </div>
                           <div class="card-body bg-light text-center">
                              <div class="mb-2">
                                 <h6 class="font-weight-semibold mb-2">
                                    <a href="#" class="text-default mb-2" data-abc="true">Toshiba Notebook with 500GB HDD & 8GB RAM</a>
                                 </h6>
                                 <a href="#" class="text-muted" data-abc="true">Laptops & Notebooks</a>
                              </div>
                              <h3 class="mb-0 font-weight-semibold">$250.99</h3>
                              <div>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                                 <i class="fa fa-star star"></i>
                              </div>
                              <div class="text-muted mb-3">34 reviews</div>
                              <button type="button" class="btn bg-cart"><i class="fa fa-cart-plus mr-2"></i> Add to cart</button>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </main>
         </div>
      </div>
   </body>
</html>