<?php
session_start();
require 'connection.php';

// echo $id;
$conn = new connection();
$conn = $conn->connect();
class Db
{
    function dbnew()
    {
        $conn = $GLOBALS['conn'];
        $sql = "CREATE DATABASE labham";
        echo $conn->query($sql);
        if ($conn->query($sql) === true)
        {
            echo "Database created successfully";
        }
        else
        {
            // echo "Error creating database: " . $conn->error;
            
        }

    }

    function table()
    {

        $conn = $GLOBALS['conn'];
        $dbuser = mysqli_select_db($conn, 'labham');
        $sql = "CREATE TABLE formdata (
            id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            firstname VARCHAR(30) NOT NULL,
            lastname VARCHAR(30) NOT NULL,
            mobileno VARCHAR(300) NOT NULL,
            email VARCHAR(50) NOT NULL,
            gender VARCHAR(50) NOT NULL,
            pswd VARCHAR(300) NOT NULL,
            cpswd VARCHAR(300) NOT NULL,
            files VARCHAR(300) NOT NULL
            )";
        if ($conn->query($sql) === true)
        {
            echo "Table MyGuests created successfully";
        }
        else
        {
            //echo "Error creating table: " . $conn->error;
            
        }

        // $conn->close();
        

        
    }

    function insert()
    {
        $conn = $GLOBALS['conn'];
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $Phoneno = $_POST['Phoneno'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $pswd = $_POST['pswd'];
        $c_password = $_POST['c_password'];
        $fileToUpload = $_POST['fileToUpload'];
        // echo $_POST['register'];
        // exit;
        

        if (isset($_POST['register']))
        {
            $sql = "INSERT INTO formdata (firstname, lastname, mobileno, email, gender, pswd, cpswd, files) VALUES('$firstname', '$lastname', '$Phoneno', '$email', '$gender', '$pswd', '$c_password', '$fileToUpload')";
            if ($conn->query($sql) === true)
            {
                header('location:login.php');
            }
            else
            {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }

    }

    function login()
    {
        // die(fdfdf);
        // exit;
        $conn = $GLOBALS['conn'];
        $Email = $_POST['Email'];
        $Password = $_POST['Password'];
        // die($Password);
        // exit;
        if (isset($_POST['login']))
        {
            $sql = "SELECT email,pswd from formdata WHERE email='$Email' and pswd='$Password'";
            //    die($sql);
            // exit;
            // $_SESSION["Email"] = $sql;
            // $_SESSION["Password"] = $sql;

            // die($_SESSION["Password"]);
            // exit;
            $result = $conn->query($sql);
           
            if ($result->num_rows > 0)
            {
                // output data of each row
                while ($row = $result->fetch_assoc())
                {
                    // echo '<pre>';print_r($row);
                    // exit;
                    $_SESSION['Email'] = $row['email'];
                    $_SESSION['Password'] = $row['pswd'];
                    
                    //  echo $_SESSION['Email'];
                    //  echo $_SESSION['Password'];
                    //  exit;

                    header('location:dashboard/dash1/index.php');
                }
            }
            else
            {
                header('location:login.php');
            }
        }
    }
    function product_db()
    {
        $conn = $GLOBALS['conn'];
        $product_name = $_POST['product_name'];
        $price = $_POST['price'];
        $Squ = $_POST['Squ'];
        $quantity = $_POST['quantity'];
        $files = $_POST['files'];
        $product_detail = $_POST['product_detail'];

        if (isset($_POST['product']))
        {
            $sql = "INSERT INTO Product (product_name, price, Squ, quantity, image, product_deatil) VALUES('$product_name', '$price', '$Squ', '$quantity', '$files', '$product_detail')";
            // echo"<pre>";print_r($sql);
            // exit;
            if ($conn->query($sql) === true)
            {
                header('location:dashboard/dash1/products.php');
            }
            else
            {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
     
    }

    function products_entry()
    {  
           $conn = $GLOBALS['conn'];                
           $query = "SELECT * FROM Product";
        //   $query_display = mysqli_query($conn,$query);
         $result = $conn->query($query);
         
         $data = [];           
         if ($result->num_rows > 0)
          {
           while ($row = $result->fetch_assoc())
           {
               $data[$row['id']] = $row;
             
           }
       return $data;
       }
    }

    function add_to_cart($id)
    {
        $conn = $GLOBALS['conn'];                
        $query = "SELECT * FROM Product where id=$id";
        $result = $conn->query($query);
        $data = [];           
        if ($result->num_rows > 0)
         {
          while ($row = $result->fetch_assoc())
          {
            return $row;
          }
      }
    }
    function update($id,$action,$quantity){
        // exit(1);
        $conn = $GLOBALS['conn'];
        if($action == 'delete'){
            $array = array();
            $sql = "DELETE from Product where id=$id";
            if ($conn->query($sql) === true)
            {
                foreach($_SESSION['data'] as $key=>$product)
              
                {
                    if($product['id']== $id){
                unset($_SESSION['data'][$key]);
        
               echo 1;
            }
        }

        }
    }
    }
}
$obj = new Db();
$obj->dbnew();
$obj->table();
$obj->insert();
$obj->login();
$obj->product_db();

if(isset( $_POST['action'])){
    $id = $_POST['product_id'];
    $quantity = $_POST['qty'];
    $action = $_POST['action'];
    $obj->update($id,$action,$quantity);
}

?>
