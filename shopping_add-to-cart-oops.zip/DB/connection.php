<?php
 class connection{

    function connect(){
      
      $servername = "localhost";
      $username = "dbuser";
      $password = "satrixdb";

      // Create connection
      $conn = new mysqli($servername, $username, $password);

      // Check connection
      if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }
      else{
        // echo "Connected successfully";
      }
   
    return $conn;
    }      
}
// $obj = new connection();
// $obj->connect();
?> 