
                               
                                $query = "SELECT * FROM demo2";

                                $query_display = mysqli_query($conn, $query);

                                if (mysqli_num_rows($query_display) > 0) {
                                    foreach ($query_display as $row) {
                                ?>
                                        <tr>
                                            <td><?= $row['id'] ?></td>
                                            <td><?= $row['firstname'] ?></td>
                                            <td><?= $row['midname'] ?></td>
                                            <td><?= $row['lastname'] ?></td>
                                            <td><?= $row['email'] ?></td>
                                            <td><?= $row['password'] ?></td>
                                            <td><?= $row['mobileno'] ?></td>
                                            <td><?= $row['file'] ?></td>
                                            <td><?= $row['gender'] ?></td>
                                            <td><a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-outline-danger">Edit</a></td>
                                            <td>
                                                <a href="../database/delete1.php?id=<?= $row['id'] ?>" class="btn btn-outline-warning">Delete</a>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                } else {
                                    ?>
                                    <tr>
                                        <td colspan="6">NO Record found</td>
                                    </tr>
                                <?php
                                }

                       